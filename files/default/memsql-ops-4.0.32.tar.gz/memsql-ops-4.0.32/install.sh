#!/bin/bash

TARGET_INSTALL_PATH="/var/lib/memsql-ops"
TARGET_GLOBAL_BINARY_PATH="/usr/bin/memsql-ops"

PLATFORM="$(uname -s)"
if [ "$PLATFORM" == "Darwin" ]; then
    echo "MemSQL does not run directly on Mac OS X." 1>&2
    echo "Either install on a Linux system or use Docker to run it on your Mac." 1>&2
    echo "To get started with MemSQL on Docker, visit our documentation:" 1>&2
    echo "http://docs.memsql.com/latest/setup/docker/" 1>&2
    exit 10
elif [ "$PLATFORM" != "Linux" ]; then
    echo "MemSQL does not support this system: ${PLATFORM}. Use a Linux system instead." 1>&2
    echo "To learn more about running MemSQL on Linux, visit our documentation:" 1>&2
    echo "http://docs.memsql.com/latest/setup/requirements/" 1>&2
    exit 11
fi

ARCH="$(uname -m)"
if [ "$ARCH" != "x86_64" ]; then
    echo "MemSQL requires an x86_64 (amd64) architecture." 1>&2
    exit 12
fi

BINARY_PATH="$(readlink -f "$0")"
ROOTPATH="$( cd "$(dirname "$BINARY_PATH")" ; pwd -P )"
MEMSQL_AGENT_PATH="$ROOTPATH/memsql-ops/lib/memsql-ops"

if [ -f "$MEMSQL_AGENT_PATH" ]; then
    exec "$MEMSQL_AGENT_PATH" agent-install "$@"
else
    if [ -f "$TARGET_INSTALL_PATH/memsql-ops" ]; then
        echo "MemSQL Ops is installed in ${TARGET_INSTALL_PATH}."
        if [ -f "$TARGET_GLOBAL_BINARY_PATH" ]; then
            echo "You can run commands via the global binary 'memsql-ops'."
        else
            echo "You can run commands via the binary '$TARGET_INSTALL_PATH/memsql-ops'."
        fi
    else
        echo "Can't find MemSQL Ops install files in local directory." 1>&2
        exit 1
    fi
fi
